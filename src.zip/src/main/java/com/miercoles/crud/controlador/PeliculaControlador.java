package com.miercoles.crud.controlador;

import com.miercoles.crud.modelo.Genero;
import com.miercoles.crud.modelo.Pelicula;
import com.miercoles.crud.servicio.GeneroServicioInterfaz;
import com.miercoles.crud.servicio.PeliculaServicioInterfaz;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.ui.Model;
import java.util.List;

@Controller
@RequestMapping("/peliculas")
public class PeliculaControlador {

    @Autowired
    private PeliculaServicioInterfaz peliculaServicio;

    @Autowired
    private GeneroServicioInterfaz generoServicio;

    @GetMapping
    public String listarPeliculas(Model modelo) {
       List<Pelicula> peliculas = peliculaServicio.obtenerTodos();
        modelo.addAttribute("peliculas", peliculas);
          // Debug en consola
        System.out.println("Películas cargadas:");
        peliculas.forEach(p -> System.out.println(p.getTitulo()));

        return "index";
    }

    @Controller
public class InicioControlador {
    @GetMapping("/")
    public String redirigir() {
        return "redirect:/peliculas";
    }
}



    @PostMapping
    public String guardarPelicula(@ModelAttribute("pelicula") Pelicula pelicula) {
        peliculaServicio.guardar(pelicula);
        return "redirect:/peliculas";
    }

   
    @GetMapping("/editar/{id}")
public String editarPelicula(@PathVariable Integer id, Model model) {
    Pelicula pelicula = peliculaServicio.obtenerPorId(id);
    List<Genero> generos = generoServicio.obtenerTodos();
    model.addAttribute("pelicula", pelicula);
    model.addAttribute("generos", generos);
    return "peliculas/editar_pelicula"; // o "crear_pelicula" según corresponda
}


    @PostMapping("/{id}")
    public String actualizarPelicula(@PathVariable Integer id, @ModelAttribute("pelicula") Pelicula pelicula) {
        pelicula.setId(id);
        peliculaServicio.guardar(pelicula);
        return "redirect:/peliculas";
    }
@GetMapping("/nuevo")
public String mostrarFormularioDeNuevaPelicula(Model model) {
    List<Genero> generos = generoServicio.obtenerTodos(); // Asegurate de que esta línea funcione y no devuelva null

    model.addAttribute("formPelicula", new Pelicula());
    model.addAttribute("generos", generos);

    return "peliculas/crear_pelicula";
}





    @GetMapping("/eliminar/{id}")
    public String eliminarPelicula(@PathVariable Integer id) {
        peliculaServicio.eliminar(id);
        return "redirect:/peliculas";
    }
}